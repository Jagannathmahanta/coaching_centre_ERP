import { ArrowRight, Calendar, Clock, GraduationCap } from "lucide-react";
import type { CatalogBatch } from "../../../shared/types/catalog";
import type { LandingTenant } from "../service";
type Props = {
  tenant: LandingTenant;
  batches: CatalogBatch[];
};

function formatTimeRange(start?: string, end?: string) {
  if (!start || !end) return "Schedule available on contact";
  return `${start.slice(0, 5)} - ${end.slice(0, 5)}`;
}

export default function UpcomingBatch({ tenant, batches }: Props) {
  const scrollTo = (id: string) => {
    const el = document.querySelector(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  const upcomingBatches = batches.slice(0, 6).map((batch) => ({
    id: batch.id,
    course: batch.batch_name || batch.class_name || batch.course_name || "Batch",
    category: batch.program_type === "academic" ? "Academic Batch" : "Program Batch",
    startDate: formatTimeRange(batch.start_time, batch.end_time),
    duration: batch.shift,
    level: batch.class_name || batch.course_name || "General",
    faculty: tenant.name,
    seats: batch.capacity ? `${batch.capacity} Seats` : "Limited Seats",
    badge: batch.shift === "morning" ? "Morning" : batch.shift === "afternoon" ? "Afternoon" : "Evening",
  }));

  return (
    <section id="upcoming" className="client-section client-section--muted">
      <div className="client-shell">
        <div className="client-sectionIntro">
          <div className="client-chip">Registrations Open</div>
          <h2>Upcoming Batches for the New Academic Session</h2>
          <p>
            Active batches from {tenant.name}. Timing and seat capacity are shown from your current catalog setup.
          </p>
        </div>

        <div className="client-grid client-grid--compact">
          {upcomingBatches.map((batch) => (
            <article key={batch.id} className="client-card client-batchCard">
              <div className="client-batchCard__top">
                <div>
                  <span className="client-batchCard__category">{batch.category}</span>
                  <h3>{batch.course}</h3>
                </div>
                <span className="client-badge">{batch.badge}</span>
              </div>

              <div className="client-batchCard__meta">
                <div>
                  <Calendar size={16} />
                  <span>{batch.startDate}</span>
                </div>
                <div>
                  <Clock size={16} />
                  <span>{batch.duration}</span>
                </div>
                <div>
                  <GraduationCap size={16} />
                  <span>{batch.level}</span>
                </div>
                {/* <div>
                  <IndianRupee size={16} />
                  <span>{batch.price}</span>
                </div> */}
              </div>

              <p className="client-batchCard__faculty">Mentored by {batch.faculty}</p>
              <div className="client-batchCard__footer">
                <span className="client-batchCard__seats">{batch.seats}</span>
                <button type="button" className="client-button client-button--primary" onClick={() => scrollTo("#contact")}>
                  Enroll Now <ArrowRight size={16} />
                </button>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
