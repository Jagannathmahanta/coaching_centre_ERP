import { ArrowRight, BookOpen, Clock3, GraduationCap } from "lucide-react";
import type { CatalogBatch, CatalogClass, CatalogCourse } from "../../../shared/types/catalog";
import type { LandingTenant } from "../service";

const images = [
  "https://images.pexels.com/photos/301926/pexels-photo-301926.jpeg?auto=compress&cs=tinysrgb&w=600",
  "https://images.pexels.com/photos/2280571/pexels-photo-2280571.jpeg?auto=compress&cs=tinysrgb&w=600",
  "https://images.pexels.com/photos/5212345/pexels-photo-5212345.jpeg?auto=compress&cs=tinysrgb&w=600",
];

type Props = {
  tenant: LandingTenant;
  classes: CatalogClass[];
  courses: CatalogCourse[];
  batches: CatalogBatch[];
};

export default function Courses({ tenant, classes, courses, batches }: Props) {
  const items = (courses.length
    ? courses.map((course, index) => ({
        title: course.course_name,
        level: "Course Program",
        duration: "Flexible",
        board: "Institute Program",
        image: images[index % images.length],
        desc: course.description || `Structured teaching and guided practice at ${tenant.name}.`,
        accent: "Course Track",
      }))
    : classes.map((cls, index) => {
        const classBatches = batches.filter((batch) => batch.class_name === cls.class_name);
        return {
          title: cls.class_name,
          level: cls.class_name,
          duration: classBatches.length ? `${classBatches.length} Active Batches` : "Academic Program",
          board: classBatches.find((batch) => batch.board)?.board || "School Program",
          image: images[index % images.length],
          desc: `Focused coaching for ${cls.class_name} with tests, doubt clearing, and classroom support.`,
          accent: "Academic Track",
        };
      })).slice(0, 6);

  return (
    <section id="courses" className="client-section">
      <div className="client-shell">
        <div className="client-sectionIntro">
          <div className="client-chip">Our Programs</div>
          <h2>Courses Designed for Academic Growth</h2>
          <p>
            Live programs from {tenant.name}. Courses and class tracks shown here are loaded from your institute setup.
          </p>
        </div>

        <div className="client-grid client-grid--compact">
          {items.map((course) => (
            <article key={course.title} className="client-card client-courseCard">
              <img src={course.image} alt={course.title} className="client-courseCard__image" />
              <div className="client-courseCard__body">
                <span className="client-badge client-badge--soft">{course.accent}</span>
                <h3>{course.title}</h3>
                <p>{course.desc}</p>

                <div className="client-courseCard__meta">
                  <span>
                    <GraduationCap size={15} />
                    {course.level}
                  </span>
                  <span>
                    <Clock3 size={15} />
                    {course.duration}
                  </span>
                  <span>
                    <BookOpen size={15} />
                    {course.board}
                  </span>
                </div>

                <button type="button" className="client-button client-button--secondary">
                  View Details <ArrowRight size={16} />
                </button>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
