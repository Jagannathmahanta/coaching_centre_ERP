import { Clock, Mail, MapPin, Phone } from "lucide-react";
import type { LandingTenant } from "../service";

type Props = {
  tenant: LandingTenant;
};

export default function Contact({ tenant }: Props) {
  const contactInfo = [
    {
      icon: MapPin,
      title: "Visit Us",
      lines: [tenant.name, tenant.address || tenant.city || "Institute address available on request"],
    },
    {
      icon: Phone,
      title: "Call Us",
      lines: [tenant.phone || "Phone available on request"],
    },
    {
      icon: Mail,
      title: "Email Us",
      lines: [tenant.email || "Email available on request"],
    },
    {
      icon: Clock,
      title: "Working Hours",
      lines: ["Mon - Sat: 7:00 AM - 9:00 PM", "Sun: 9:00 AM - 5:00 PM"],
    },
  ];

  const mapQuery = encodeURIComponent([tenant.address, tenant.city, tenant.name].filter(Boolean).join(", "));

  return (
    <section id="contact" className="client-section">
      <div className="client-shell">
        <div className="client-sectionIntro">
          <div className="client-chip">Get In Touch</div>
          <h2>Talk to Our Admission Team</h2>
          <p>
            Share your details and our counsellors will guide you to the right class and batch.
          </p>
        </div>

        <div className="client-contact">
          <div className="client-contact__details">
            {contactInfo.map(({ icon: Icon, title, lines }) => (
              <article key={title} className="client-contactInfo">
                <span className="client-contactInfo__icon">
                  <Icon size={18} />
                </span>
                <div>
                  <h3>{title}</h3>
                  {lines.map((line) => (
                    <p key={line}>{line}</p>
                  ))}
                </div>
              </article>
            ))}

            <div className="client-contact__map">
              <iframe
                title={`${tenant.name} Location`}
                src={`https://www.google.com/maps?q=${mapQuery}&z=14&output=embed`}
                loading="lazy"
                allowFullScreen
              />
            </div>
          </div>

          <div className="client-contact__formCard client-contact__cta">
            <div className="client-chip">Admissions 2026-27</div>
            <h3>Visit, Call, or WhatsApp to Reserve a Seat</h3>
            <p>
              Contact {tenant.name} directly for batch timing, fee details, and seat availability.
            </p>

            <div className="client-contact__ctaList">
              <div>
                <strong>Available Courses</strong>
                <span>Live catalog from institute setup</span>
              </div>
              <div>
                <strong>Batch Size</strong>
                <span>Limited to 20 seats per batch</span>
              </div>
              <div>
                <strong>Support</strong>
                <span>Monthly tests, doubt clearing, and guided revision</span>
              </div>
            </div>

            <div className="client-contact__ctaActions">
              <a className="client-button client-button--primary client-button--block" href={`tel:${tenant.phone || ""}`}>
                Call Now
              </a>
              <a className="client-button client-button--ghost client-button--block" href={`mailto:${tenant.email || ""}`}>
                Email Us
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
