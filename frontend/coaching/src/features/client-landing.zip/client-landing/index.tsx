import "./landing.css";
import { useEffect, useMemo, useState } from "react";
import { useLocation } from "react-router-dom";
import Navbar from "./componets/Navbar";
import Hero from "./componets/Hero";
import UpcomingBatch from "./componets/upcomingBatch";
import Courses from "./componets/Courses";
import Faculty from "./componets/Faculity";
import Contact from "./componets/Contact";
import Footer from "./componets/Footer";
import {
  getPublicLanding,
  resolveLandingSlug,
  type LandingTenant,
  type PublicLandingPayload,
} from "./service";

export default function LandingPage() {
  const location = useLocation();
  const [landingData, setLandingData] = useState<PublicLandingPayload | null>(null);

  const slug = useMemo(() => resolveLandingSlug(location.search), [location.search]);

  useEffect(() => {
    let active = true;

    if (!slug) {
      setLandingData(null);
      return () => {
        active = false;
      };
    }

    getPublicLanding(slug)
      .then((data) => {
        if (active) {
          setLandingData(data);
        }
      })
      .catch(() => {
        if (active) {
          setLandingData(null);
        }
      });

    return () => {
      active = false;
    };
  }, [slug]);

  const fallbackTenant: LandingTenant = {
    id: 0,
    name: "Home Tutorial Hub",
    slug: "",
    city: "Dhenkikote",
    address: "Dhenkikote, Odisha, India",
    phone: "+91 8249668484",
    email: "dibyalochan.naik1989@gmail.com",
    logo_url: null,
  };

  const tenant = landingData?.tenant || fallbackTenant;

  return (
    <div className="client-landing">
      <Navbar tenant={tenant} />
      <Hero tenant={tenant} />
      <UpcomingBatch tenant={tenant} batches={landingData?.batches || []} />
      <Courses
        tenant={tenant}
        classes={landingData?.classes || []}
        courses={landingData?.courses || []}
        batches={landingData?.batches || []}
      />
      <Faculty />
      <Contact tenant={tenant} />
      <Footer tenant={tenant} />
    </div>
  );
}
