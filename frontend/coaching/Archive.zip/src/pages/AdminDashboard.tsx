import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Users, BookOpen, Bell, DollarSign, Home, Bus, TrendingUp, AlertCircle } from 'lucide-react';

interface Stats {
  totalStudents: number;
  activeStudents: number;
  totalExams: number;
  pendingFees: number;
  hostelOccupancy: number;
  transportUsers: number;
}

export default function AdminDashboard() {
  const [stats, setStats] = useState<Stats>({
    totalStudents: 0,
    activeStudents: 0,
    totalExams: 0,
    pendingFees: 0,
    hostelOccupancy: 0,
    transportUsers: 0,
  });
  const [recentNotices, setRecentNotices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const [studentsRes, examsRes, feesRes, hostelRes, transportRes, noticesRes] = await Promise.all([
        supabase.from('students').select('*', { count: 'exact' }),
        supabase.from('exams').select('*', { count: 'exact' }),
        supabase.from('fees').select('*').eq('status', 'pending'),
        supabase.from('hostel_allocations').select('*', { count: 'exact' }).eq('status', 'active'),
        supabase.from('transport_allocations').select('*', { count: 'exact' }).eq('status', 'active'),
        supabase.from('notices').select('*').order('created_at', { ascending: false }).limit(5),
      ]);

      const activeStudents = studentsRes.data?.filter(s => s.status === 'active').length || 0;

      setStats({
        totalStudents: studentsRes.count || 0,
        activeStudents,
        totalExams: examsRes.count || 0,
        pendingFees: feesRes.data?.length || 0,
        hostelOccupancy: hostelRes.count || 0,
        transportUsers: transportRes.count || 0,
      });

      setRecentNotices(noticesRes.data || []);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const statCards = [
    { icon: Users, label: 'Total Students', value: stats.totalStudents, color: 'bg-blue-500', subtext: `${stats.activeStudents} active` },
    { icon: BookOpen, label: 'Total Exams', value: stats.totalExams, color: 'bg-green-500', subtext: 'This semester' },
    { icon: DollarSign, label: 'Pending Fees', value: stats.pendingFees, color: 'bg-yellow-500', subtext: 'Students with dues' },
    { icon: Home, label: 'Hostel Students', value: stats.hostelOccupancy, color: 'bg-purple-500', subtext: 'Rooms occupied' },
    { icon: Bus, label: 'Transport Users', value: stats.transportUsers, color: 'bg-orange-500', subtext: 'Active riders' },
    { icon: TrendingUp, label: 'Performance', value: '92%', color: 'bg-teal-500', subtext: 'Overall average' },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-800">Admin Dashboard</h1>
        <p className="text-gray-600 mt-1">Overview of your coaching center</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {statCards.map((card, index) => {
          const Icon = card.icon;
          return (
            <div key={index} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition">
              <div className="flex items-center justify-between mb-4">
                <div className={`${card.color} p-3 rounded-lg`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
              </div>
              <h3 className="text-3xl font-bold text-gray-800 mb-1">{card.value}</h3>
              <p className="text-gray-600 font-medium">{card.label}</p>
              <p className="text-sm text-gray-500 mt-1">{card.subtext}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-800">Recent Notices</h2>
            <Bell className="w-5 h-5 text-gray-400" />
          </div>
          <div className="space-y-4">
            {recentNotices.length === 0 ? (
              <p className="text-gray-500 text-center py-8">No notices posted yet</p>
            ) : (
              recentNotices.map((notice) => (
                <div key={notice.id} className="border-l-4 border-blue-500 bg-blue-50 p-4 rounded-r-lg">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-800">{notice.title}</h3>
                      <p className="text-sm text-gray-600 mt-1 line-clamp-2">{notice.content}</p>
                    </div>
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      notice.category === 'urgent' ? 'bg-red-100 text-red-700' :
                      notice.category === 'academic' ? 'bg-green-100 text-green-700' :
                      'bg-gray-100 text-gray-700'
                    }`}>
                      {notice.category}
                    </span>
                  </div>
                  <p className="text-xs text-gray-500 mt-2">
                    {new Date(notice.created_at).toLocaleDateString()}
                  </p>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-800">Quick Actions</h2>
            <AlertCircle className="w-5 h-5 text-gray-400" />
          </div>
          <div className="space-y-3">
            <button className="w-full bg-blue-50 hover:bg-blue-100 text-blue-700 font-medium py-3 px-4 rounded-lg transition text-left">
              Add New Student
            </button>
            <button className="w-full bg-green-50 hover:bg-green-100 text-green-700 font-medium py-3 px-4 rounded-lg transition text-left">
              Schedule New Exam
            </button>
            <button className="w-full bg-yellow-50 hover:bg-yellow-100 text-yellow-700 font-medium py-3 px-4 rounded-lg transition text-left">
              Post Notice
            </button>
            <button className="w-full bg-purple-50 hover:bg-purple-100 text-purple-700 font-medium py-3 px-4 rounded-lg transition text-left">
              Generate Fee Reports
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
