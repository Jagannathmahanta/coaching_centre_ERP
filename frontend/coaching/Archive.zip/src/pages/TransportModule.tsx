import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { Bus, MapPin, Phone, Plus } from 'lucide-react';

export default function TransportModule() {
  const { profile } = useAuth();
  const [routes, setRoutes] = useState<any[]>([]);
  const [allocations, setAllocations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTransportData();
  }, [profile]);

  const fetchTransportData = async () => {
    try {
      const { data: routesData, error: routesError } = await supabase
        .from('transport_routes')
        .select('*')
        .order('route_name', { ascending: true });

      if (routesError) throw routesError;
      setRoutes(routesData || []);

      let allocationsQuery = supabase
        .from('transport_allocations')
        .select('*, students(*), transport_routes(*)')
        .eq('status', 'active');

      if (profile?.role === 'student') {
        const { data: studentData } = await supabase
          .from('students')
          .select('id')
          .eq('user_id', profile.id)
          .maybeSingle();

        if (studentData) {
          allocationsQuery = allocationsQuery.eq('student_id', studentData.id);
        }
      } else if (profile?.role === 'parent') {
        const { data: parentData } = await supabase
          .from('parents')
          .select('student_id')
          .eq('user_id', profile.id);

        const studentIds = parentData?.map(p => p.student_id) || [];
        if (studentIds.length > 0) {
          allocationsQuery = allocationsQuery.in('student_id', studentIds);
        }
      }

      const { data: allocationsData, error: allocationsError } = await allocationsQuery;
      if (allocationsError) throw allocationsError;
      setAllocations(allocationsData || []);
    } catch (error) {
      console.error('Error fetching transport data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading transport data...</p>
        </div>
      </div>
    );
  }

  const totalRoutes = routes.length;
  const totalCapacity = routes.reduce((sum, route) => sum + route.capacity, 0);
  const totalOccupied = routes.reduce((sum, route) => sum + (route.occupied || 0), 0);
  const utilizationRate = totalCapacity > 0 ? Math.round((totalOccupied / totalCapacity) * 100) : 0;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Transport Management</h1>
          <p className="text-gray-600 mt-1">Manage transport routes and allocations</p>
        </div>
        {profile?.role === 'admin' && (
          <button className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg transition">
            <Plus className="w-5 h-5" />
            <span className="font-medium">Add Route</span>
          </button>
        )}
      </div>

      {profile?.role === 'admin' && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-blue-100 p-3 rounded-lg">
                <Bus className="w-6 h-6 text-blue-600" />
              </div>
            </div>
            <h3 className="text-3xl font-bold text-gray-800">{totalRoutes}</h3>
            <p className="text-gray-600 font-medium">Total Routes</p>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-green-100 p-3 rounded-lg">
                <Bus className="w-6 h-6 text-green-600" />
              </div>
            </div>
            <h3 className="text-3xl font-bold text-gray-800">{totalCapacity}</h3>
            <p className="text-gray-600 font-medium">Total Capacity</p>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-orange-100 p-3 rounded-lg">
                <Bus className="w-6 h-6 text-orange-600" />
              </div>
            </div>
            <h3 className="text-3xl font-bold text-gray-800">{totalOccupied}</h3>
            <p className="text-gray-600 font-medium">Students Using</p>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-purple-100 p-3 rounded-lg">
                <Bus className="w-6 h-6 text-purple-600" />
              </div>
            </div>
            <h3 className="text-3xl font-bold text-gray-800">{utilizationRate}%</h3>
            <p className="text-gray-600 font-medium">Utilization</p>
          </div>
        </div>
      )}

      {profile?.role === 'admin' ? (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-bold text-gray-800 mb-6">Route Overview</h2>
          <div className="space-y-4">
            {routes.length === 0 ? (
              <div className="text-center py-12 text-gray-500">
                No routes added yet
              </div>
            ) : (
              routes.map((route) => (
                <div key={route.id} className="bg-gradient-to-br from-orange-50 to-orange-100 p-6 rounded-xl border border-orange-200">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <h3 className="text-2xl font-bold text-gray-800 mb-2">{route.route_name}</h3>
                      <div className="flex items-center space-x-4 text-sm text-gray-700">
                        <div className="flex items-center space-x-2">
                          <Bus className="w-4 h-4" />
                          <span>{route.vehicle_number}</span>
                        </div>
                        {route.driver_name && (
                          <div className="flex items-center space-x-2">
                            <span>{route.driver_name}</span>
                          </div>
                        )}
                        {route.driver_phone && (
                          <div className="flex items-center space-x-2">
                            <Phone className="w-4 h-4" />
                            <span>{route.driver_phone}</span>
                          </div>
                        )}
                      </div>
                    </div>
                    <Bus className="w-8 h-8 text-orange-600" />
                  </div>

                  <div className="grid grid-cols-3 gap-4 mb-4">
                    <div>
                      <p className="text-sm text-gray-600">Capacity</p>
                      <p className="text-xl font-bold text-gray-800">{route.capacity}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Occupied</p>
                      <p className="text-xl font-bold text-gray-800">{route.occupied || 0}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Available</p>
                      <p className="text-xl font-bold text-gray-800">
                        {route.capacity - (route.occupied || 0)}
                      </p>
                    </div>
                  </div>

                  {route.pickup_points && (
                    <div className="pt-4 border-t border-orange-200">
                      <div className="flex items-start space-x-2">
                        <MapPin className="w-4 h-4 text-gray-600 mt-1" />
                        <div>
                          <p className="text-sm text-gray-600 mb-1">Pickup Points:</p>
                          <p className="text-gray-700">{route.pickup_points}</p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-bold text-gray-800 mb-6">Your Transport Information</h2>
          {allocations.length === 0 ? (
            <div className="text-center py-12">
              <Bus className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">No transport allocation found</p>
            </div>
          ) : (
            <div className="space-y-4">
              {allocations.map((allocation) => (
                <div key={allocation.id} className="bg-gradient-to-br from-orange-50 to-orange-100 p-6 rounded-xl border border-orange-200">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-2xl font-bold text-gray-800">
                        {allocation.transport_routes.route_name}
                      </h3>
                      {allocation.students && (
                        <p className="text-gray-700 mt-1">
                          Roll No: {allocation.students.roll_number}
                        </p>
                      )}
                    </div>
                    <Bus className="w-8 h-8 text-orange-600" />
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <p className="text-sm text-gray-600">Vehicle Number</p>
                      <p className="text-lg font-semibold text-gray-800">
                        {allocation.transport_routes.vehicle_number}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Status</p>
                      <span className="inline-block px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-700">
                        Active
                      </span>
                    </div>
                  </div>

                  {allocation.transport_routes.driver_name && (
                    <div className="mb-4">
                      <p className="text-sm text-gray-600">Driver Information</p>
                      <div className="flex items-center justify-between mt-1">
                        <p className="text-lg font-semibold text-gray-800">
                          {allocation.transport_routes.driver_name}
                        </p>
                        {allocation.transport_routes.driver_phone && (
                          <div className="flex items-center space-x-2 text-gray-700">
                            <Phone className="w-4 h-4" />
                            <span>{allocation.transport_routes.driver_phone}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {allocation.pickup_point && (
                    <div className="pt-4 border-t border-orange-200">
                      <div className="flex items-center space-x-2">
                        <MapPin className="w-5 h-5 text-gray-600" />
                        <div>
                          <p className="text-sm text-gray-600">Your Pickup Point</p>
                          <p className="text-lg font-semibold text-gray-800">{allocation.pickup_point}</p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
