import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { BookOpen, Bell, DollarSign, Home, Bus, Award, Calendar } from 'lucide-react';

export default function StudentDashboard() {
  const { user } = useAuth();
  const [studentData, setStudentData] = useState<any>(null);
  const [upcomingExams, setUpcomingExams] = useState<any[]>([]);
  const [recentNotices, setRecentNotices] = useState<any[]>([]);
  const [pendingFees, setPendingFees] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchStudentData();
    }
  }, [user]);

  const fetchStudentData = async () => {
    try {
      const { data: student } = await supabase
        .from('students')
        .select('*')
        .eq('user_id', user?.id)
        .maybeSingle();

      if (!student) return;

      setStudentData(student);

      const [examsRes, noticesRes, feesRes] = await Promise.all([
        supabase
          .from('exams')
          .select('*')
          .eq('class', student.class)
          .gte('exam_date', new Date().toISOString().split('T')[0])
          .order('exam_date', { ascending: true })
          .limit(5),
        supabase
          .from('notices')
          .select('*')
          .order('created_at', { ascending: false })
          .limit(5),
        supabase
          .from('fees')
          .select('*')
          .eq('student_id', student.id)
          .eq('status', 'pending'),
      ]);

      setUpcomingExams(examsRes.data || []);
      setRecentNotices(noticesRes.data || []);
      setPendingFees(feesRes.data || []);
    } catch (error) {
      console.error('Error fetching student data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  if (!studentData) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <p className="text-gray-600">No student profile found</p>
        </div>
      </div>
    );
  }

  const totalPendingAmount = pendingFees.reduce((sum, fee) => sum + Number(fee.amount), 0);

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-xl shadow-lg p-6 text-white">
        <h1 className="text-3xl font-bold mb-2">Student Portal</h1>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
          <div>
            <p className="text-blue-100 text-sm">Roll Number</p>
            <p className="text-xl font-bold">{studentData.roll_number}</p>
          </div>
          <div>
            <p className="text-blue-100 text-sm">Class</p>
            <p className="text-xl font-bold">{studentData.class} {studentData.section}</p>
          </div>
          <div>
            <p className="text-blue-100 text-sm">Hostel</p>
            <p className="text-xl font-bold">{studentData.is_hostel ? 'Yes' : 'No'}</p>
          </div>
          <div>
            <p className="text-blue-100 text-sm">Transport</p>
            <p className="text-xl font-bold">{studentData.is_transport ? 'Yes' : 'No'}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-green-100 p-3 rounded-lg">
              <BookOpen className="w-6 h-6 text-green-600" />
            </div>
          </div>
          <h3 className="text-3xl font-bold text-gray-800">{upcomingExams.length}</h3>
          <p className="text-gray-600 font-medium">Upcoming Exams</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-red-100 p-3 rounded-lg">
              <DollarSign className="w-6 h-6 text-red-600" />
            </div>
          </div>
          <h3 className="text-3xl font-bold text-gray-800">₹{totalPendingAmount}</h3>
          <p className="text-gray-600 font-medium">Pending Fees</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-blue-100 p-3 rounded-lg">
              <Award className="w-6 h-6 text-blue-600" />
            </div>
          </div>
          <h3 className="text-3xl font-bold text-gray-800">92%</h3>
          <p className="text-gray-600 font-medium">Average Score</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-800">Upcoming Exams</h2>
            <Calendar className="w-5 h-5 text-gray-400" />
          </div>
          <div className="space-y-3">
            {upcomingExams.length === 0 ? (
              <p className="text-gray-500 text-center py-8">No upcoming exams</p>
            ) : (
              upcomingExams.map((exam) => (
                <div key={exam.id} className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-semibold text-gray-800">{exam.name}</h3>
                    <span className="text-xs px-2 py-1 bg-blue-100 text-blue-700 rounded-full">
                      {exam.exam_type}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600">{exam.subject}</p>
                  <div className="flex justify-between items-center mt-3 text-sm">
                    <span className="text-gray-500">
                      {new Date(exam.exam_date).toLocaleDateString()}
                    </span>
                    <span className="text-gray-700 font-medium">
                      {exam.total_marks} marks
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-800">Recent Notices</h2>
            <Bell className="w-5 h-5 text-gray-400" />
          </div>
          <div className="space-y-3">
            {recentNotices.length === 0 ? (
              <p className="text-gray-500 text-center py-8">No notices</p>
            ) : (
              recentNotices.map((notice) => (
                <div key={notice.id} className="border-l-4 border-blue-500 bg-blue-50 p-4 rounded-r-lg">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-semibold text-gray-800">{notice.title}</h3>
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      notice.category === 'urgent' ? 'bg-red-100 text-red-700' :
                      notice.category === 'academic' ? 'bg-green-100 text-green-700' :
                      'bg-gray-100 text-gray-700'
                    }`}>
                      {notice.category}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600 line-clamp-2">{notice.content}</p>
                  <p className="text-xs text-gray-500 mt-2">
                    {new Date(notice.created_at).toLocaleDateString()}
                  </p>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {pendingFees.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-bold text-gray-800 mb-4">Pending Fees</h2>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-3 px-4 text-gray-700 font-semibold">Fee Type</th>
                  <th className="text-left py-3 px-4 text-gray-700 font-semibold">Amount</th>
                  <th className="text-left py-3 px-4 text-gray-700 font-semibold">Due Date</th>
                  <th className="text-left py-3 px-4 text-gray-700 font-semibold">Status</th>
                </tr>
              </thead>
              <tbody>
                {pendingFees.map((fee) => (
                  <tr key={fee.id} className="border-b border-gray-100">
                    <td className="py-3 px-4 capitalize">{fee.fee_type}</td>
                    <td className="py-3 px-4 font-semibold">₹{fee.amount}</td>
                    <td className="py-3 px-4">{new Date(fee.due_date).toLocaleDateString()}</td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-1 bg-yellow-100 text-yellow-700 rounded-full text-xs">
                        {fee.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
