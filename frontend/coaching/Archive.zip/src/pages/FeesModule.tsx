import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { DollarSign, CreditCard, CheckCircle, AlertCircle } from 'lucide-react';

export default function FeesModule() {
  const { profile } = useAuth();
  const [fees, setFees] = useState<any[]>([]);
  const [payments, setPayments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'pending' | 'paid'>('pending');

  useEffect(() => {
    fetchFeesData();
  }, [profile]);

  const fetchFeesData = async () => {
    try {
      let feesQuery = supabase.from('fees').select('*, students(*)');

      if (profile?.role === 'student') {
        const { data: studentData } = await supabase
          .from('students')
          .select('id')
          .eq('user_id', profile.id)
          .maybeSingle();

        if (studentData) {
          feesQuery = feesQuery.eq('student_id', studentData.id);
        }
      } else if (profile?.role === 'parent') {
        const { data: parentData } = await supabase
          .from('parents')
          .select('student_id')
          .eq('user_id', profile.id);

        const studentIds = parentData?.map(p => p.student_id) || [];
        if (studentIds.length > 0) {
          feesQuery = feesQuery.in('student_id', studentIds);
        }
      }

      const { data: feesData, error: feesError } = await feesQuery.order('due_date', { ascending: true });
      if (feesError) throw feesError;
      setFees(feesData || []);

      if (feesData && feesData.length > 0) {
        const feeIds = feesData.map(f => f.id);
        const { data: paymentsData } = await supabase
          .from('fee_payments')
          .select('*')
          .in('fee_id', feeIds);
        setPayments(paymentsData || []);
      }
    } catch (error) {
      console.error('Error fetching fees data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading fees...</p>
        </div>
      </div>
    );
  }

  const pendingFees = fees.filter(f => f.status === 'pending' || f.status === 'overdue');
  const paidFees = fees.filter(f => f.status === 'paid');
  const totalPending = pendingFees.reduce((sum, fee) => sum + Number(fee.amount), 0);
  const totalPaid = paidFees.reduce((sum, fee) => sum + Number(fee.amount), 0);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-800">Fee Management</h1>
        <p className="text-gray-600 mt-1">Track and manage fee payments</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-red-100 p-3 rounded-lg">
              <AlertCircle className="w-6 h-6 text-red-600" />
            </div>
          </div>
          <h3 className="text-3xl font-bold text-gray-800">₹{totalPending}</h3>
          <p className="text-gray-600 font-medium">Total Pending</p>
          <p className="text-sm text-gray-500 mt-1">{pendingFees.length} pending items</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-green-100 p-3 rounded-lg">
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
          </div>
          <h3 className="text-3xl font-bold text-gray-800">₹{totalPaid}</h3>
          <p className="text-gray-600 font-medium">Total Paid</p>
          <p className="text-sm text-gray-500 mt-1">{paidFees.length} paid items</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-blue-100 p-3 rounded-lg">
              <DollarSign className="w-6 h-6 text-blue-600" />
            </div>
          </div>
          <h3 className="text-3xl font-bold text-gray-800">₹{totalPending + totalPaid}</h3>
          <p className="text-gray-600 font-medium">Total Fees</p>
          <p className="text-sm text-gray-500 mt-1">{fees.length} total items</p>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="border-b border-gray-200">
          <div className="flex">
            <button
              onClick={() => setActiveTab('pending')}
              className={`flex-1 py-4 px-6 font-medium transition ${
                activeTab === 'pending'
                  ? 'border-b-2 border-blue-600 text-blue-600'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              Pending ({pendingFees.length})
            </button>
            <button
              onClick={() => setActiveTab('paid')}
              className={`flex-1 py-4 px-6 font-medium transition ${
                activeTab === 'paid'
                  ? 'border-b-2 border-blue-600 text-blue-600'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              Paid ({paidFees.length})
            </button>
          </div>
        </div>

        <div className="p-6">
          {activeTab === 'pending' ? (
            <div className="space-y-4">
              {pendingFees.length === 0 ? (
                <div className="text-center py-12">
                  <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                  <p className="text-gray-500">All fees are paid!</p>
                </div>
              ) : (
                pendingFees.map((fee) => (
                  <div key={fee.id} className="bg-yellow-50 border border-yellow-200 p-6 rounded-lg">
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex-1">
                        <h3 className="text-lg font-bold text-gray-800 capitalize">{fee.fee_type} Fee</h3>
                        {fee.students && (
                          <p className="text-sm text-gray-600 mt-1">
                            Roll No: {fee.students.roll_number} - Class: {fee.students.class}
                          </p>
                        )}
                      </div>
                      <CreditCard className="w-6 h-6 text-gray-400" />
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                      <div>
                        <p className="text-sm text-gray-600">Amount</p>
                        <p className="text-2xl font-bold text-gray-800">₹{fee.amount}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Due Date</p>
                        <p className="text-lg font-semibold text-gray-800">
                          {new Date(fee.due_date).toLocaleDateString()}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Status</p>
                        <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium mt-1 ${
                          fee.status === 'overdue' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'
                        }`}>
                          {fee.status}
                        </span>
                      </div>
                    </div>
                    {profile?.role === 'admin' && (
                      <button className="mt-4 bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition">
                        Record Payment
                      </button>
                    )}
                  </div>
                ))
              )}
            </div>
          ) : (
            <div className="space-y-4">
              {paidFees.length === 0 ? (
                <div className="text-center py-12 text-gray-500">
                  No paid fees
                </div>
              ) : (
                paidFees.map((fee) => (
                  <div key={fee.id} className="bg-green-50 border border-green-200 p-6 rounded-lg">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <h3 className="text-lg font-bold text-gray-800 capitalize">{fee.fee_type} Fee</h3>
                        {fee.students && (
                          <p className="text-sm text-gray-600 mt-1">
                            Roll No: {fee.students.roll_number} - Class: {fee.students.class}
                          </p>
                        )}
                      </div>
                      <CheckCircle className="w-6 h-6 text-green-600" />
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mt-4">
                      <div>
                        <p className="text-sm text-gray-600">Amount</p>
                        <p className="text-2xl font-bold text-gray-800">₹{fee.amount}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Paid On</p>
                        <p className="text-lg font-semibold text-gray-800">
                          {new Date(fee.due_date).toLocaleDateString()}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Status</p>
                        <span className="inline-block px-3 py-1 rounded-full text-sm font-medium mt-1 bg-green-100 text-green-700">
                          Paid
                        </span>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
