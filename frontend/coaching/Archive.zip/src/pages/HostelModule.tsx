import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { Home, Users, Plus } from 'lucide-react';

export default function HostelModule() {
  const { profile } = useAuth();
  const [rooms, setRooms] = useState<any[]>([]);
  const [allocations, setAllocations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchHostelData();
  }, [profile]);

  const fetchHostelData = async () => {
    try {
      const { data: roomsData, error: roomsError } = await supabase
        .from('hostel_rooms')
        .select('*')
        .order('room_number', { ascending: true });

      if (roomsError) throw roomsError;
      setRooms(roomsData || []);

      let allocationsQuery = supabase
        .from('hostel_allocations')
        .select('*, students(*), hostel_rooms(*)')
        .eq('status', 'active');

      if (profile?.role === 'student') {
        const { data: studentData } = await supabase
          .from('students')
          .select('id')
          .eq('user_id', profile.id)
          .maybeSingle();

        if (studentData) {
          allocationsQuery = allocationsQuery.eq('student_id', studentData.id);
        }
      } else if (profile?.role === 'parent') {
        const { data: parentData } = await supabase
          .from('parents')
          .select('student_id')
          .eq('user_id', profile.id);

        const studentIds = parentData?.map(p => p.student_id) || [];
        if (studentIds.length > 0) {
          allocationsQuery = allocationsQuery.in('student_id', studentIds);
        }
      }

      const { data: allocationsData, error: allocationsError } = await allocationsQuery;
      if (allocationsError) throw allocationsError;
      setAllocations(allocationsData || []);
    } catch (error) {
      console.error('Error fetching hostel data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading hostel data...</p>
        </div>
      </div>
    );
  }

  const totalRooms = rooms.length;
  const totalCapacity = rooms.reduce((sum, room) => sum + room.capacity, 0);
  const totalOccupied = rooms.reduce((sum, room) => sum + (room.occupied || 0), 0);
  const occupancyRate = totalCapacity > 0 ? Math.round((totalOccupied / totalCapacity) * 100) : 0;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Hostel Management</h1>
          <p className="text-gray-600 mt-1">Manage hostel rooms and allocations</p>
        </div>
        {profile?.role === 'admin' && (
          <button className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg transition">
            <Plus className="w-5 h-5" />
            <span className="font-medium">Add Room</span>
          </button>
        )}
      </div>

      {profile?.role === 'admin' && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-blue-100 p-3 rounded-lg">
                <Home className="w-6 h-6 text-blue-600" />
              </div>
            </div>
            <h3 className="text-3xl font-bold text-gray-800">{totalRooms}</h3>
            <p className="text-gray-600 font-medium">Total Rooms</p>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-green-100 p-3 rounded-lg">
                <Users className="w-6 h-6 text-green-600" />
              </div>
            </div>
            <h3 className="text-3xl font-bold text-gray-800">{totalCapacity}</h3>
            <p className="text-gray-600 font-medium">Total Capacity</p>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-purple-100 p-3 rounded-lg">
                <Users className="w-6 h-6 text-purple-600" />
              </div>
            </div>
            <h3 className="text-3xl font-bold text-gray-800">{totalOccupied}</h3>
            <p className="text-gray-600 font-medium">Occupied</p>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-orange-100 p-3 rounded-lg">
                <Users className="w-6 h-6 text-orange-600" />
              </div>
            </div>
            <h3 className="text-3xl font-bold text-gray-800">{occupancyRate}%</h3>
            <p className="text-gray-600 font-medium">Occupancy</p>
          </div>
        </div>
      )}

      {profile?.role === 'admin' ? (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-bold text-gray-800 mb-6">Room Overview</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {rooms.length === 0 ? (
              <div className="col-span-full text-center py-12 text-gray-500">
                No rooms added yet
              </div>
            ) : (
              rooms.map((room) => (
                <div key={room.id} className="bg-gradient-to-br from-purple-50 to-purple-100 p-6 rounded-xl border border-purple-200">
                  <div className="flex items-start justify-between mb-4">
                    <Home className="w-8 h-8 text-purple-600" />
                    <span className="text-xs px-2 py-1 bg-purple-600 text-white rounded-full capitalize">
                      {room.room_type}
                    </span>
                  </div>
                  <h3 className="text-2xl font-bold text-gray-800 mb-2">Room {room.room_number}</h3>
                  {room.floor && (
                    <p className="text-gray-700 mb-4">Floor: {room.floor}</p>
                  )}
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Capacity:</span>
                      <span className="font-semibold text-gray-800">{room.capacity}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Occupied:</span>
                      <span className="font-semibold text-gray-800">{room.occupied || 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Available:</span>
                      <span className="font-semibold text-gray-800">
                        {room.capacity - (room.occupied || 0)}
                      </span>
                    </div>
                  </div>
                  {room.facilities && (
                    <div className="mt-4 pt-4 border-t border-purple-200">
                      <p className="text-xs text-gray-600">Facilities:</p>
                      <p className="text-sm text-gray-700">{room.facilities}</p>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-bold text-gray-800 mb-6">Your Hostel Information</h2>
          {allocations.length === 0 ? (
            <div className="text-center py-12">
              <Home className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">No hostel allocation found</p>
            </div>
          ) : (
            <div className="space-y-4">
              {allocations.map((allocation) => (
                <div key={allocation.id} className="bg-gradient-to-br from-purple-50 to-purple-100 p-6 rounded-xl border border-purple-200">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-2xl font-bold text-gray-800">
                        Room {allocation.hostel_rooms.room_number}
                      </h3>
                      {allocation.students && (
                        <p className="text-gray-700 mt-1">
                          Roll No: {allocation.students.roll_number}
                        </p>
                      )}
                    </div>
                    <Home className="w-8 h-8 text-purple-600" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-600">Floor</p>
                      <p className="text-lg font-semibold text-gray-800">
                        {allocation.hostel_rooms.floor || 'N/A'}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Room Type</p>
                      <p className="text-lg font-semibold text-gray-800 capitalize">
                        {allocation.hostel_rooms.room_type}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Allocation Date</p>
                      <p className="text-lg font-semibold text-gray-800">
                        {new Date(allocation.allocation_date).toLocaleDateString()}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Status</p>
                      <span className="inline-block px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-700">
                        Active
                      </span>
                    </div>
                  </div>
                  {allocation.hostel_rooms.facilities && (
                    <div className="mt-4 pt-4 border-t border-purple-200">
                      <p className="text-sm text-gray-600 mb-2">Facilities:</p>
                      <p className="text-gray-700">{allocation.hostel_rooms.facilities}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
