import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { Calendar, Plus, FileText } from 'lucide-react';

export default function ExamsModule() {
  const { profile } = useAuth();
  const [exams, setExams] = useState<any[]>([]);
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'upcoming' | 'results'>('upcoming');

  useEffect(() => {
    fetchExams();
    if (profile?.role !== 'admin') {
      fetchResults();
    }
  }, [profile]);

  const fetchExams = async () => {
    try {
      const { data, error } = await supabase
        .from('exams')
        .select('*')
        .order('exam_date', { ascending: true });

      if (error) throw error;
      setExams(data || []);
    } catch (error) {
      console.error('Error fetching exams:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchResults = async () => {
    try {
      let query = supabase
        .from('exam_results')
        .select('*, exams(*), students(*)');

      if (profile?.role === 'student') {
        const { data: studentData } = await supabase
          .from('students')
          .select('id')
          .eq('user_id', profile.id)
          .maybeSingle();

        if (studentData) {
          query = query.eq('student_id', studentData.id);
        }
      } else if (profile?.role === 'parent') {
        const { data: parentData } = await supabase
          .from('parents')
          .select('student_id')
          .eq('user_id', profile.id);

        const studentIds = parentData?.map(p => p.student_id) || [];
        if (studentIds.length > 0) {
          query = query.in('student_id', studentIds);
        }
      }

      const { data, error } = await query;
      if (error) throw error;
      setResults(data || []);
    } catch (error) {
      console.error('Error fetching results:', error);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading exams...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Exams</h1>
          <p className="text-gray-600 mt-1">View and manage examinations</p>
        </div>
        {profile?.role === 'admin' && (
          <button className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg transition">
            <Plus className="w-5 h-5" />
            <span className="font-medium">Schedule Exam</span>
          </button>
        )}
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="border-b border-gray-200">
          <div className="flex">
            <button
              onClick={() => setActiveTab('upcoming')}
              className={`flex-1 py-4 px-6 font-medium transition ${
                activeTab === 'upcoming'
                  ? 'border-b-2 border-blue-600 text-blue-600'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              Upcoming Exams
            </button>
            {profile?.role !== 'admin' && (
              <button
                onClick={() => setActiveTab('results')}
                className={`flex-1 py-4 px-6 font-medium transition ${
                  activeTab === 'results'
                    ? 'border-b-2 border-blue-600 text-blue-600'
                    : 'text-gray-600 hover:text-gray-800'
                }`}
              >
                Results
              </button>
            )}
          </div>
        </div>

        <div className="p-6">
          {activeTab === 'upcoming' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {exams.length === 0 ? (
                <div className="col-span-full text-center py-12 text-gray-500">
                  No exams scheduled
                </div>
              ) : (
                exams.map((exam) => (
                  <div key={exam.id} className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-xl border border-blue-200">
                    <div className="flex items-start justify-between mb-4">
                      <Calendar className="w-8 h-8 text-blue-600" />
                      <span className="text-xs px-2 py-1 bg-blue-600 text-white rounded-full">
                        {exam.exam_type}
                      </span>
                    </div>
                    <h3 className="text-xl font-bold text-gray-800 mb-2">{exam.name}</h3>
                    <p className="text-gray-700 mb-4">{exam.subject}</p>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Class:</span>
                        <span className="font-semibold text-gray-800">{exam.class}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Date:</span>
                        <span className="font-semibold text-gray-800">
                          {new Date(exam.exam_date).toLocaleDateString()}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Total Marks:</span>
                        <span className="font-semibold text-gray-800">{exam.total_marks}</span>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          ) : (
            <div className="space-y-4">
              {results.length === 0 ? (
                <div className="text-center py-12 text-gray-500">
                  No results available
                </div>
              ) : (
                results.map((result) => (
                  <div key={result.id} className="bg-gray-50 p-6 rounded-lg">
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex-1">
                        <h3 className="text-lg font-bold text-gray-800">{result.exams.name}</h3>
                        <p className="text-gray-600">{result.exams.subject}</p>
                        {result.students && (
                          <p className="text-sm text-gray-500 mt-1">
                            Roll No: {result.students.roll_number}
                          </p>
                        )}
                      </div>
                      <FileText className="w-6 h-6 text-gray-400" />
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div>
                        <p className="text-sm text-gray-600">Marks Obtained</p>
                        <p className="text-2xl font-bold text-gray-800">{result.marks_obtained}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Total Marks</p>
                        <p className="text-2xl font-bold text-gray-800">{result.exams.total_marks}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Percentage</p>
                        <p className="text-2xl font-bold text-gray-800">
                          {((result.marks_obtained / result.exams.total_marks) * 100).toFixed(1)}%
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Grade</p>
                        <p className="text-2xl font-bold text-gray-800">{result.grade || 'N/A'}</p>
                      </div>
                    </div>
                    {result.remarks && (
                      <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                        <p className="text-sm text-gray-600">Remarks:</p>
                        <p className="text-gray-800">{result.remarks}</p>
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
