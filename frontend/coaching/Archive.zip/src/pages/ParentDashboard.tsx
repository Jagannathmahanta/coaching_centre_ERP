import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { User, BookOpen, Award, DollarSign, TrendingUp, Calendar } from 'lucide-react';

export default function ParentDashboard() {
  const { user } = useAuth();
  const [children, setChildren] = useState<any[]>([]);
  const [selectedChild, setSelectedChild] = useState<any>(null);
  const [examResults, setExamResults] = useState<any[]>([]);
  const [pendingFees, setPendingFees] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchParentData();
    }
  }, [user]);

  useEffect(() => {
    if (selectedChild) {
      fetchChildDetails();
    }
  }, [selectedChild]);

  const fetchParentData = async () => {
    try {
      const { data: parentData } = await supabase
        .from('parents')
        .select('student_id')
        .eq('user_id', user?.id);

      if (!parentData || parentData.length === 0) return;

      const studentIds = parentData.map(p => p.student_id);
      const { data: studentsData } = await supabase
        .from('students')
        .select('*')
        .in('id', studentIds);

      if (studentsData && studentsData.length > 0) {
        setChildren(studentsData);
        setSelectedChild(studentsData[0]);
      }
    } catch (error) {
      console.error('Error fetching parent data:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchChildDetails = async () => {
    if (!selectedChild) return;

    try {
      const [resultsRes, feesRes] = await Promise.all([
        supabase
          .from('exam_results')
          .select('*, exams(*)')
          .eq('student_id', selectedChild.id)
          .order('created_at', { ascending: false })
          .limit(10),
        supabase
          .from('fees')
          .select('*')
          .eq('student_id', selectedChild.id)
          .eq('status', 'pending'),
      ]);

      setExamResults(resultsRes.data || []);
      setPendingFees(feesRes.data || []);
    } catch (error) {
      console.error('Error fetching child details:', error);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  if (children.length === 0) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <p className="text-gray-600">No children profiles found</p>
        </div>
      </div>
    );
  }

  const totalPendingFees = pendingFees.reduce((sum, fee) => sum + Number(fee.amount), 0);
  const averageScore = examResults.length > 0
    ? Math.round(examResults.reduce((sum, result) => sum + (result.marks_obtained / result.exams.total_marks) * 100, 0) / examResults.length)
    : 0;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-800">Parent Portal</h1>
        <p className="text-gray-600 mt-1">Monitor your child's academic progress</p>
      </div>

      {children.length > 1 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">Select Child</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {children.map((child) => (
              <button
                key={child.id}
                onClick={() => setSelectedChild(child)}
                className={`p-4 rounded-lg border-2 transition ${
                  selectedChild?.id === child.id
                    ? 'border-blue-600 bg-blue-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <User className="w-8 h-8 mx-auto mb-2 text-gray-600" />
                <p className="font-semibold text-gray-800 text-center">{child.roll_number}</p>
                <p className="text-sm text-gray-600 text-center">{child.class}</p>
              </button>
            ))}
          </div>
        </div>
      )}

      {selectedChild && (
        <>
          <div className="bg-gradient-to-r from-green-600 to-green-700 rounded-xl shadow-lg p-6 text-white">
            <h2 className="text-2xl font-bold mb-4">Student Information</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <p className="text-green-100 text-sm">Roll Number</p>
                <p className="text-xl font-bold">{selectedChild.roll_number}</p>
              </div>
              <div>
                <p className="text-green-100 text-sm">Class</p>
                <p className="text-xl font-bold">{selectedChild.class} {selectedChild.section}</p>
              </div>
              <div>
                <p className="text-green-100 text-sm">Blood Group</p>
                <p className="text-xl font-bold">{selectedChild.blood_group || 'N/A'}</p>
              </div>
              <div>
                <p className="text-green-100 text-sm">Status</p>
                <p className="text-xl font-bold capitalize">{selectedChild.status}</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="bg-blue-100 p-3 rounded-lg">
                  <BookOpen className="w-6 h-6 text-blue-600" />
                </div>
              </div>
              <h3 className="text-3xl font-bold text-gray-800">{examResults.length}</h3>
              <p className="text-gray-600 font-medium">Exams Taken</p>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="bg-green-100 p-3 rounded-lg">
                  <TrendingUp className="w-6 h-6 text-green-600" />
                </div>
              </div>
              <h3 className="text-3xl font-bold text-gray-800">{averageScore}%</h3>
              <p className="text-gray-600 font-medium">Average Score</p>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="bg-red-100 p-3 rounded-lg">
                  <DollarSign className="w-6 h-6 text-red-600" />
                </div>
              </div>
              <h3 className="text-3xl font-bold text-gray-800">₹{totalPendingFees}</h3>
              <p className="text-gray-600 font-medium">Pending Fees</p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-gray-800">Recent Exam Results</h2>
                <Award className="w-5 h-5 text-gray-400" />
              </div>
              <div className="space-y-3">
                {examResults.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">No exam results yet</p>
                ) : (
                  examResults.map((result) => (
                    <div key={result.id} className="bg-gray-50 p-4 rounded-lg">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h3 className="font-semibold text-gray-800">{result.exams.name}</h3>
                          <p className="text-sm text-gray-600">{result.exams.subject}</p>
                        </div>
                        <span className={`text-lg font-bold ${
                          (result.marks_obtained / result.exams.total_marks) * 100 >= 75 ? 'text-green-600' :
                          (result.marks_obtained / result.exams.total_marks) * 100 >= 50 ? 'text-yellow-600' :
                          'text-red-600'
                        }`}>
                          {result.marks_obtained}/{result.exams.total_marks}
                        </span>
                      </div>
                      <div className="flex justify-between items-center mt-2">
                        <span className="text-sm text-gray-500">
                          Grade: <span className="font-semibold">{result.grade || 'N/A'}</span>
                        </span>
                        <span className="text-sm text-gray-500">
                          {((result.marks_obtained / result.exams.total_marks) * 100).toFixed(1)}%
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-gray-800">Fee Details</h2>
                <DollarSign className="w-5 h-5 text-gray-400" />
              </div>
              {pendingFees.length === 0 ? (
                <div className="text-center py-8">
                  <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Award className="w-8 h-8 text-green-600" />
                  </div>
                  <p className="text-gray-600">All fees paid!</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {pendingFees.map((fee) => (
                    <div key={fee.id} className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-semibold text-gray-800 capitalize">{fee.fee_type}</h3>
                          <p className="text-sm text-gray-600 mt-1">
                            Due: {new Date(fee.due_date).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-xl font-bold text-gray-800">₹{fee.amount}</p>
                          <span className="text-xs px-2 py-1 bg-yellow-200 text-yellow-800 rounded-full">
                            {fee.status}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
