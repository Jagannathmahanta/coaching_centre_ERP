import API from "./api";

export const hostelService = {
  getAll: async () => {
    const [hostels, rooms, allocations] = await Promise.all([
      API.get("/hostel"),
      API.get("/hostel/rooms/list"),
      API.get("/hostel/allocations/list", {
        params: { active_only: true },
      }),
    ]);

    return {
      hostels: hostels.data,
      rooms: rooms.data,
      allocations: allocations.data,
    };
  },

  createHostel: (data: any) => API.post("/hostel", data),
  updateHostel: (id: number, data: any) =>
    API.patch(`/hostel/${id}`, data),

  createRoom: (data: any) => API.post("/hostel/rooms", data),
  updateRoom: (id: number, data: any) =>
    API.patch(`/hostel/rooms/${id}`, data),
};