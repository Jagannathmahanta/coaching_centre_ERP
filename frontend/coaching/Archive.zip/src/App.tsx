import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from "./layout/Layout";
import Dashboard from "./modules/dashboard/DashboardPage";
import StudentsPage from "./modules/students/StudentsPage";
import NewStudentPage from "./modules/students/NewStudentPage";
import FeesPage from "./modules/fees/FeesPage";
import TransportPage from "./modules/transport/TransportPage";
import HostelPage from "./modules/hostel/HostelPage";
import TeachersPage from "./modules/teacher/TeachersPage";
import TeacherSalaryPage from "./modules/teacher/TeacherSalaryPage";
import ExamsPage from "./modules/exams/ExamsPage";
import AttendancePage from "./modules/attendance/AttendancePage";
import HolidayPage from "./modules/holiday/HolidayPage";
import LeavePage from "./modules/leave/LeavePage";
import NoticesPage from "./modules/notice/NoticesPage";
import ParentsPage from "./modules/parent/ParentsPage";
import LoginPage from "./modules/auth/LoginPage.tsx";
import ProtectedRoute from "./modules/auth/ProtectedRoute.tsx";
import NotFoundPage from "./modules/NotFoundPage";
import SignupPage from "./modules/auth/SignupPage.tsx";
import DashboardRoute  from "./features/dashboard/routes/DashboardRoute.tsx";
export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/signup" element={<SignupPage />} />
        <Route element={<ProtectedRoute><Layout /></ProtectedRoute>}>
          <Route path="/" element={<DashboardRoute />} />
          <Route path="/students" element={<StudentsPage />} />
          <Route path="/students/new" element={<NewStudentPage />} />
          <Route path="/students/:id/edit" element={<NewStudentPage />} />
          <Route path="/fees" element={<FeesPage />} />
          <Route path="/transport" element={<TransportPage />} />
          <Route path="/hostel" element={<HostelPage />} />
          <Route path="/teachers" element={<TeachersPage />} />
          <Route path="/teacher-salary" element={<TeacherSalaryPage />} />
          <Route path="/exams" element={<ExamsPage />} />
          <Route path="/attendance" element={<AttendancePage />} />
          <Route path="/holidays" element={<HolidayPage />} />
          <Route path="/leaves" element={<LeavePage />} />
          <Route path="/notices" element={<NoticesPage />} />
          <Route path="/parents" element={<ParentsPage />} />
          <Route path="*" element={<NotFoundPage />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
