import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { hostelService } from "../services/hostel.service";

export const useHostelQuery = () => {
  const queryClient = useQueryClient();

  // ✅ GET
  const query = useQuery({
    queryKey: ["hostel"],
    queryFn: hostelService.getAll,
  });

  // ✅ CREATE HOSTEL
  const createHostel = useMutation({
    mutationFn: hostelService.createHostel,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["hostel"] });
    },
  });

  // ✅ UPDATE HOSTEL
  const updateHostel = useMutation({
    mutationFn: ({ id, data }: any) =>
      hostelService.updateHostel(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["hostel"] });
    },
  });

  // ✅ ROOM
  const createRoom = useMutation({
    mutationFn: hostelService.createRoom,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["hostel"] });
    },
  });

  const updateRoom = useMutation({
    mutationFn: ({ id, data }: any) =>
      hostelService.updateRoom(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["hostel"] });
    },
  });

  return {
    ...query,
    createHostel,
    updateHostel,
    createRoom,
    updateRoom,
  };
};