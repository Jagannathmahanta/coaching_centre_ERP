import "./landing.css";
import { useMemo } from "react";
import { useLocation } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import Navbar from "./componets/Navbar";
import Hero from "./componets/Hero";
import UpcomingBatch from "./componets/upcomingBatch";
import Courses from "./componets/Courses";
import Faculty from "./componets/Faculity";
import Contact from "./componets/Contact";
import Footer from "./componets/Footer";
import { buildOrganizationSchema, useDocumentSeo } from "../../shared/seo/useDocumentSeo";
import { getPublicLanding, resolveLandingSlug } from "./service";

export default function LandingPage() {
  const location = useLocation();
  const slug = useMemo(() => resolveLandingSlug(location.search), [location.search]);
  const { data } = useQuery({
    queryKey: ["public-landing", slug],
    queryFn: () => getPublicLanding(slug),
    enabled: Boolean(slug),
    staleTime: 5 * 60 * 1000,
  });

  const tenant = data?.tenant;
  const canonicalUrl = typeof window === "undefined"
    ? `https://${slug}.tutorialhub.co.in/`
    : `${window.location.origin}/`;
  const headline = tenant?.name || (slug ? slug.replace(/-/g, " ") : "Institute");
  const courseNames = [...(data?.classes || []).map((item) => item.class_name), ...(data?.courses || []).map((item) => item.course_name)]
    .filter(Boolean)
    .slice(0, 3);
  const description = tenant
    ? `${tenant.name}${tenant.city ? ` in ${tenant.city}` : ""} on TutorialHub ERP. Explore active classes, courses, upcoming batches, and institute contact details online.`
    : `${headline} on TutorialHub ERP. Explore classes, courses, batches, and institute contact details online.`;
  const keywords = [
    tenant?.name,
    tenant?.slug,
    tenant?.city,
    ...courseNames,
    "coaching institute",
    "tutorialhub erp",
  ].filter(Boolean) as string[];

  useDocumentSeo({
    title: tenant ? `${tenant.name} | Student Portal | TutorialHub ERP` : `${headline} | TutorialHub ERP`,
    description,
    canonicalUrl,
    url: canonicalUrl,
    image: tenant?.logo_url || "/ogimage.png",
    keywords,
    schema: buildOrganizationSchema({
      name: tenant?.name || headline,
      url: canonicalUrl,
      description,
      image: tenant?.logo_url || "/ogimage.png",
      email: tenant?.email,
      phone: tenant?.phone,
      address: tenant?.address,
    }),
  });

  return (
    <div className="client-landing">
      <Navbar />
      <Hero />
      <UpcomingBatch />
      <Courses />
      <Faculty />
      <Contact />
      <Footer />
    </div>
  );
}
