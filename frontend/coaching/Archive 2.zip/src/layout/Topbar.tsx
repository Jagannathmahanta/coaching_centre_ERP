import { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { clearAuth, getUser } from "../shared/services/auth";

type Props = {
    mobileMenuOpen: boolean;
    onMenuToggle: () => void;
};

export default function Topbar({ mobileMenuOpen, onMenuToggle }: Props) {
    const navigate = useNavigate();
    const user = useMemo(() => getUser(), []);
    void mobileMenuOpen;

    const handleLogout = () => {
        clearAuth();
        navigate("/login", { replace: true });
    };

    return (
        <div className="appTopbar">
            <div className="appTopbar__start">
                <button
                    type="button"
                    className="appTopbar__menuButton"
                    onClick={onMenuToggle}
                >
                    ☰
                </button>

                <strong className="appTopbar__title">
                    Odisha Coaching System
                </strong>
            </div>

            {/* Hide this on mobile */}
            <div className="appTopbar__actions appTopbar__actions--desktop">
                <span className="appTopbar__welcome">
                    {user ? `Welcome, ${user.name || user.email}` : "Guest"}
                </span>
                <button onClick={handleLogout} className="appTopbar__logout">
                    Logout
                </button>
            </div>
        </div>
    );
}
