import { useMemo } from "react";
import { useLocation } from "react-router-dom";
import { useDocumentSeo } from "./useDocumentSeo";

function detectCenterSlugFromHost(hostname: string) {
  const normalizedHost = hostname.toLowerCase();
  if (
    !normalizedHost ||
    normalizedHost === "localhost" ||
    normalizedHost === "127.0.0.1" ||
    normalizedHost.endsWith(".localhost")
  ) {
    return "";
  }

  const parts = normalizedHost.split(".");
  if (parts.length < 3 || parts[0] === "www") {
    return "";
  }

  return parts[0];
}

function titleCase(value: string) {
  return value
    .split("-")
    .filter(Boolean)
    .map((segment) => segment.charAt(0).toUpperCase() + segment.slice(1))
    .join(" ");
}

export default function RouteSeo() {
  const location = useLocation();

  const payload = useMemo(() => {
    const currentUrl = typeof window === "undefined" ? "" : window.location.href;
    const currentOrigin = typeof window === "undefined" ? "" : window.location.origin;
    const hostname = typeof window === "undefined" ? "" : window.location.hostname;
    const centerSlug = detectCenterSlugFromHost(hostname);
    const centerLabel = centerSlug ? titleCase(centerSlug) : "TutorialHub";
    const query = new URLSearchParams(location.search);
    const role = query.get("role");

    if (location.pathname === "/login") {
      const roleLabel = role ? `${titleCase(role)} Login` : "Login";
      return {
        title: `${roleLabel} | ${centerLabel} | TutorialHub ERP`,
        description: centerSlug
          ? `Secure ${role || "institute"} login for ${centerLabel} on TutorialHub ERP.`
          : "Secure login for admins, teachers, students, and parents on TutorialHub ERP.",
        canonicalUrl: currentUrl,
        robots: "index, follow",
        keywords: ["tutorialhub erp login", "institute login", centerSlug].filter(Boolean),
        image: "/ogimage.png",
        url: currentUrl,
      };
    }

    if (location.pathname === "/signup") {
      return {
        title: "Create Institute Account | TutorialHub ERP",
        description:
          "Register your coaching institute on TutorialHub ERP and launch your branded student portal.",
        canonicalUrl: currentUrl,
        robots: "index, follow",
        keywords: ["tutorialhub erp signup", "coaching institute software", "student portal"],
        image: "/ogimage.png",
        url: currentUrl,
      };
    }

    if (location.pathname !== "/") {
      return {
        title: "TutorialHub ERP",
        description: "Private institute workspace on TutorialHub ERP.",
        canonicalUrl: `${currentOrigin}${location.pathname}`,
        robots: "noindex, nofollow",
        image: "/ogimage.png",
        url: currentUrl,
      };
    }

    return null;
  }, [location.pathname, location.search]);

  useDocumentSeo(payload);

  return null;
}
