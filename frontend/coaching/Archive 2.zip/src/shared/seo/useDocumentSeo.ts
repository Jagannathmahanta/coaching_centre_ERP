import { useEffect } from "react";

export type SeoPayload = {
  title: string;
  description: string;
  canonicalUrl?: string;
  robots?: string;
  keywords?: string[];
  image?: string;
  url?: string;
  type?: string;
  schema?: Record<string, unknown> | Array<Record<string, unknown>>;
};

function toAbsoluteUrl(value?: string) {
  if (!value) {
    return "";
  }

  if (/^https?:\/\//i.test(value)) {
    return value;
  }

  if (typeof window === "undefined") {
    return value;
  }

  return new URL(value, window.location.origin).toString();
}

function ensureMeta(selector: string, attributes: Record<string, string>) {
  let element = document.head.querySelector<HTMLMetaElement>(selector);
  if (!element) {
    element = document.createElement("meta");
    document.head.appendChild(element);
  }

  Object.entries(attributes).forEach(([key, value]) => {
    element?.setAttribute(key, value);
  });

  return element;
}

function ensureLink(selector: string, attributes: Record<string, string>) {
  let element = document.head.querySelector<HTMLLinkElement>(selector);
  if (!element) {
    element = document.createElement("link");
    document.head.appendChild(element);
  }

  Object.entries(attributes).forEach(([key, value]) => {
    element?.setAttribute(key, value);
  });

  return element;
}

export function useDocumentSeo(payload: SeoPayload | null) {
  useEffect(() => {
    if (!payload) {
      return;
    }

    const canonicalUrl = toAbsoluteUrl(payload.canonicalUrl || window.location.href);
    const imageUrl = toAbsoluteUrl(payload.image || "/ogimage.png");
    const pageUrl = toAbsoluteUrl(payload.url || canonicalUrl);
    const robots = payload.robots || "index, follow";
    const keywords = payload.keywords?.filter(Boolean).join(", ");

    document.title = payload.title;

    ensureLink('link[rel="canonical"]', {
      rel: "canonical",
      href: canonicalUrl,
    });

    ensureMeta('meta[name="description"]', {
      name: "description",
      content: payload.description,
    });
    ensureMeta('meta[name="robots"]', {
      name: "robots",
      content: robots,
    });
    ensureMeta('meta[name="twitter:card"]', {
      name: "twitter:card",
      content: "summary_large_image",
    });
    ensureMeta('meta[name="twitter:title"]', {
      name: "twitter:title",
      content: payload.title,
    });
    ensureMeta('meta[name="twitter:description"]', {
      name: "twitter:description",
      content: payload.description,
    });
    ensureMeta('meta[name="twitter:image"]', {
      name: "twitter:image",
      content: imageUrl,
    });

    if (keywords) {
      ensureMeta('meta[name="keywords"]', {
        name: "keywords",
        content: keywords,
      });
    }

    ensureMeta('meta[property="og:site_name"]', {
      property: "og:site_name",
      content: "TutorialHub ERP",
    });
    ensureMeta('meta[property="og:title"]', {
      property: "og:title",
      content: payload.title,
    });
    ensureMeta('meta[property="og:description"]', {
      property: "og:description",
      content: payload.description,
    });
    ensureMeta('meta[property="og:image"]', {
      property: "og:image",
      content: imageUrl,
    });
    ensureMeta('meta[property="og:url"]', {
      property: "og:url",
      content: pageUrl,
    });
    ensureMeta('meta[property="og:type"]', {
      property: "og:type",
      content: payload.type || "website",
    });

    const schemaValue = payload.schema
      ? JSON.stringify(Array.isArray(payload.schema) ? payload.schema : [payload.schema])
      : "";

    let schemaScript = document.head.querySelector<HTMLScriptElement>(
      'script[data-seo-schema="runtime"]',
    );

    if (!schemaScript) {
      schemaScript = document.createElement("script");
      schemaScript.type = "application/ld+json";
      schemaScript.dataset.seoSchema = "runtime";
      document.head.appendChild(schemaScript);
    }

    schemaScript.textContent = schemaValue;
  }, [payload]);
}

export function buildOrganizationSchema(input: {
  name: string;
  url: string;
  description: string;
  image?: string;
  email?: string | null;
  phone?: string | null;
  address?: string | null;
}) {
  return {
    "@context": "https://schema.org",
    "@type": "EducationalOrganization",
    name: input.name,
    url: toAbsoluteUrl(input.url),
    description: input.description,
    image: toAbsoluteUrl(input.image || "/ogimage.png"),
    email: input.email || undefined,
    telephone: input.phone || undefined,
    address: input.address || undefined,
  };
}
