const pool = require("../../config/db");

const toNumber = (value) => Number(value || 0);

const buildAttendancePeriod = (row) => {
  const data = row || {};
  const totalMarked = toNumber(data.total_marked);
  const presentCount = toNumber(data.present_count);
  const absentCount = toNumber(data.absent_count);
  const leaveCount = toNumber(data.leave_count);

  return {
    present_count: presentCount,
    absent_count: absentCount,
    leave_count: leaveCount,
    total_marked: totalMarked,
    present_percentage: totalMarked > 0 ? Number(((presentCount / totalMarked) * 100).toFixed(1)) : 0,
  };
};

exports.getDashboard = async (req) => {
  const cid = req.user.center_id;

  const [
    studentStatsRes,
    teacherStatsRes,
    feeStatsRes,
    upcomingExamsRes,
    recentResultsRes,
    recentNoticesRes,
    upcomingHolidaysRes,
    pendingFeesRes,
    monthlyOverviewRes,
    admissionsComparisonRes,
    attendanceComparisonRes,
    todayAttendanceRes,
    classWiseStudentsRes,
    courseWiseStudentsRes,
  ] = await Promise.all([
    pool.query(
      `
      SELECT 
        COUNT(*) as total_students,
        COUNT(*) FILTER (WHERE status='active') as active_students
      FROM students 
      WHERE center_id=$1
      `,
      [cid]
    ),

    pool.query(
      `
      SELECT
        COUNT(*) AS total_teachers,
        COUNT(*) FILTER (WHERE status = 'active') AS active_teachers
      FROM teachers
      WHERE center_id = $1
      `,
      [cid]
    ),

    pool.query(
      `
      SELECT 
        COALESCE(SUM(paid_amount),0) as collected_this_month,
        COALESCE(SUM(balance),0) as pending_this_month,
        COUNT(*) FILTER (WHERE status IN ('pending', 'partial') AND balance > 0) as pending_fee_count
      FROM fees 
      WHERE center_id=$1 
      AND date_trunc('month', due_date) = date_trunc('month', CURRENT_DATE)
      `,
      [cid]
    ),

    pool.query(
      `
      SELECT
        id,
        exam_name,
        subject,
        class,
        board,
        academic_year,
        exam_date,
        time,
        0 AS results_count
      FROM exams
      WHERE center_id = $1
        AND exam_date >= CURRENT_DATE
        AND exam_date <= CURRENT_DATE + INTERVAL '30 days'
      ORDER BY exam_date ASC, time NULLS LAST
      LIMIT 6
      `,
      [cid]
    ),

    pool.query(
      `
      SELECT
        e.id AS exam_id,
        e.exam_name,
        e.subject,
        e.class,
        e.exam_date,
        COUNT(er.id) AS result_count,
        MAX(er.created_at) AS last_result_at
      FROM exam_results er
      JOIN exams e ON e.id = er.exam_id
      WHERE e.center_id = $1
      GROUP BY e.id
      ORDER BY MAX(er.created_at) DESC
      LIMIT 8
      `,
      [cid]
    ),

    pool.query(
      `
      SELECT
        id,
        title,
        content,
        priority,
        target_audience,
        expires_at,
        created_at
      FROM notices 
      WHERE center_id=$1 
        AND (expires_at IS NULL OR expires_at >= CURRENT_DATE)
      ORDER BY created_at DESC
      LIMIT 5
      `,
      [cid]
    ),

    pool.query(
      `
      SELECT
        id,
        title,
        description AS content,
        start_date,
        end_date,
        status,
        created_at
      FROM holidays
      WHERE center_id = $1
        AND status = 'active'
        AND end_date >= CURRENT_DATE
      ORDER BY start_date ASC, end_date ASC
      LIMIT 5
      `,
      [cid]
    ),

    pool.query(
      `
      SELECT
        f.id AS fee_id,
        s.name AS student_name,
        s.class,
        s.roll_number,
        f.installment_label,
        f.due_date,
        f.balance,
        f.total_amount,
        f.status
      FROM fees f
      JOIN students s ON s.id = f.student_id
      WHERE f.center_id = $1
        AND f.status IN ('pending', 'partial')
        AND f.balance > 0
      ORDER BY f.due_date ASC, f.balance DESC
      LIMIT 8
      `,
      [cid]
    ),

    pool.query(
      `
      WITH months AS (
        SELECT generate_series(
          date_trunc('month', CURRENT_DATE) - INTERVAL '5 months',
          date_trunc('month', CURRENT_DATE),
          INTERVAL '1 month'
        )::date AS month_start
      ),
      collections AS (
        SELECT
          date_trunc('month', payment_date)::date AS month_start,
          COALESCE(SUM(amount), 0) AS collected_amount
        FROM fee_payments
        WHERE center_id = $1
        GROUP BY 1
      ),
      pending AS (
        SELECT
          date_trunc('month', due_date)::date AS month_start,
          COALESCE(SUM(balance), 0) AS pending_amount
        FROM fees
        WHERE center_id = $1
        GROUP BY 1
      ),
      enrollments AS (
        SELECT
          date_trunc('month', join_date)::date AS month_start,
          COUNT(*) AS new_enrollments
        FROM students
        WHERE center_id = $1
        GROUP BY 1
      )
      SELECT
        m.month_start,
        TO_CHAR(m.month_start, 'Mon') AS month_label,
        COALESCE(c.collected_amount, 0) AS collected_amount,
        COALESCE(p.pending_amount, 0) AS pending_amount,
        COALESCE(e.new_enrollments, 0) AS new_enrollments
      FROM months m
      LEFT JOIN collections c ON c.month_start = m.month_start
      LEFT JOIN pending p ON p.month_start = m.month_start
      LEFT JOIN enrollments e ON e.month_start = m.month_start
      ORDER BY m.month_start ASC
      `,
      [cid]
    ),

    pool.query(
      `
      SELECT
        COUNT(*) FILTER (
          WHERE join_date >= date_trunc('month', CURRENT_DATE)
            AND join_date < date_trunc('month', CURRENT_DATE) + INTERVAL '1 month'
        ) AS this_month,
        COUNT(*) FILTER (
          WHERE join_date >= date_trunc('month', CURRENT_DATE) - INTERVAL '1 month'
            AND join_date < date_trunc('month', CURRENT_DATE)
        ) AS last_month
      FROM students
      WHERE center_id = $1
      `,
      [cid]
    ),

    pool.query(
      `
      WITH periods AS (
        SELECT
          'this_month'::text AS period,
          date_trunc('month', CURRENT_DATE)::date AS start_date,
          CURRENT_DATE::date AS end_date
        UNION ALL
        SELECT
          'last_month'::text AS period,
          (date_trunc('month', CURRENT_DATE) - INTERVAL '1 month')::date AS start_date,
          (date_trunc('month', CURRENT_DATE) - INTERVAL '1 day')::date AS end_date
      )
      SELECT
        p.period,
        COUNT(sa.id) AS total_marked,
        COUNT(*) FILTER (WHERE sa.status = 'present') AS present_count,
        COUNT(*) FILTER (WHERE sa.status = 'absent') AS absent_count,
        COUNT(*) FILTER (WHERE sa.status = 'leave') AS leave_count
      FROM periods p
      LEFT JOIN student_attendance sa
        ON sa.center_id = $1
       AND sa.attendance_date BETWEEN p.start_date AND p.end_date
      GROUP BY p.period
      ORDER BY p.period DESC
      `,
      [cid]
    ),

    pool.query(
      `
      SELECT
        COUNT(id) AS total_marked,
        COUNT(*) FILTER (WHERE status = 'present') AS present_count,
        COUNT(*) FILTER (WHERE status = 'absent') AS absent_count,
        COUNT(*) FILTER (WHERE status = 'leave') AS leave_count
      FROM student_attendance
      WHERE center_id = $1
        AND attendance_date = CURRENT_DATE
      `,
      [cid]
    ),

    pool.query(
      `
      SELECT
        s.class AS label,
        COUNT(*)::int AS value
      FROM students s
      WHERE s.center_id = $1
        AND s.status = 'active'
      GROUP BY s.class
      ORDER BY value DESC, label ASC
      `,
      [cid]
    ),

    pool.query(
      `
      SELECT
        fs.course_name AS label,
        COUNT(DISTINCT s.id)::int AS value
      FROM students s
      JOIN student_fee_profiles fp
        ON fp.student_id = s.id
       AND fp.center_id = s.center_id
       AND fp.status = 'active'
      JOIN fee_structures fs
        ON fs.id = fp.fee_structure_id
      WHERE s.center_id = $1
        AND s.status = 'active'
        AND fs.program_type = 'course'
        AND fs.course_name IS NOT NULL
      GROUP BY fs.course_name
      ORDER BY value DESC, label ASC
      `,
      [cid]
    ),
  ]);

  const admissionCounts = admissionsComparisonRes.rows[0] || {};
  const thisMonthAdmissions = toNumber(admissionCounts.this_month);
  const lastMonthAdmissions = toNumber(admissionCounts.last_month);
  const admissionsChangePercent =
    lastMonthAdmissions > 0
      ? Number((((thisMonthAdmissions - lastMonthAdmissions) / lastMonthAdmissions) * 100).toFixed(1))
      : thisMonthAdmissions > 0
        ? 100
        : 0;

  const attendanceMap = attendanceComparisonRes.rows.reduce((acc, row) => {
    acc[row.period] = buildAttendancePeriod(row);
    return acc;
  }, {});

  return {
    stats: {
      total_students: toNumber(studentStatsRes.rows[0] && studentStatsRes.rows[0].total_students),
      active_students: toNumber(studentStatsRes.rows[0] && studentStatsRes.rows[0].active_students),
      total_teachers: toNumber(teacherStatsRes.rows[0] && teacherStatsRes.rows[0].total_teachers),
      active_teachers: toNumber(teacherStatsRes.rows[0] && teacherStatsRes.rows[0].active_teachers),
      collected_this_month: toNumber(feeStatsRes.rows[0] && feeStatsRes.rows[0].collected_this_month),
      pending_this_month: toNumber(feeStatsRes.rows[0] && feeStatsRes.rows[0].pending_this_month),
      pending_fee_count: toNumber(feeStatsRes.rows[0] && feeStatsRes.rows[0].pending_fee_count),
      upcoming_exam_count: upcomingExamsRes.rowCount,
      recent_result_count: recentResultsRes.rowCount,
      active_notice_count: recentNoticesRes.rowCount,
      holiday_notice_count: upcomingHolidaysRes.rowCount,
    },
    analytics: {
      monthly_overview: monthlyOverviewRes.rows.map((row) => ({
        month_start: row.month_start,
        month_label: String(row.month_label).trim(),
        collected_amount: toNumber(row.collected_amount),
        pending_amount: toNumber(row.pending_amount),
        new_enrollments: toNumber(row.new_enrollments),
      })),
      admissions_comparison: {
        this_month: thisMonthAdmissions,
        last_month: lastMonthAdmissions,
        change_percent: admissionsChangePercent,
      },
      today_attendance: buildAttendancePeriod(todayAttendanceRes.rows[0]),
      attendance_comparison: {
        this_month: attendanceMap.this_month || buildAttendancePeriod(),
        last_month: attendanceMap.last_month || buildAttendancePeriod(),
      },
      class_wise_students: classWiseStudentsRes.rows.map((row) => ({
        label: row.label,
        value: toNumber(row.value),
      })),
      course_wise_students: courseWiseStudentsRes.rows.map((row) => ({
        label: row.label,
        value: toNumber(row.value),
      })),
    },
    recent_notices: recentNoticesRes.rows,
    upcoming_exams: upcomingExamsRes.rows,
    recent_results: recentResultsRes.rows,
    upcoming_holidays: upcomingHolidaysRes.rows,
    pending_fees: pendingFeesRes.rows.map((row) => ({
      ...row,
      balance: toNumber(row.balance),
      total_amount: toNumber(row.total_amount),
    })),
  };
};
